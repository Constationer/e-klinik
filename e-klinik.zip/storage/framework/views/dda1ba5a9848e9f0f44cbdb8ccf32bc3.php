  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span> <?php echo e($setting->value); ?> </span></strong>. All Rights Reserved
    </div>
  </footer><!-- End Footer --><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/partials/footer.blade.php ENDPATH**/ ?>