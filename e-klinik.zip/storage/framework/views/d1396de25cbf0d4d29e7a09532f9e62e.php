<?php $__env->startSection('content'); ?>

<section>
    <form action="<?php echo e(route('pengaturan_user_update')); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="card">

            
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($errors); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            

            <div class="card-body">
                <div class="row">                    
                    <div class="col-lg-6">
                        <div class="mb-2 mt-2">
                            <label for="" class="form-label">Nama*</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="mb-2">
                            <label for="" class="form-label">Email*</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="mb-2">
                            <label for="" class="form-label">Telepon*</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="mb-2">
                            <label for="" class="form-label">Password (isi jika ganti password)</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="mb-2 mt-4">
                            <button type="submit" class="btn btn-info">Simpan</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fahmi/Sites/e-klinik/resources/views/pengaturan-user.blade.php ENDPATH**/ ?>