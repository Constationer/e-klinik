<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title> <?php echo e($title); ?></title>
</head>

<table border="0">
    <tbody>
        <tr>
            <td>
                <img src="<?php echo e(public_path() . '/assets/img/logo.png'); ?>" width="100px" height="100px">
            </td>
            <td>
                Klinik Umum<br />
                Badan Pemeriksa Keuangan Republik Indonesia<br />
                Perwakilan Provinsi Sulawesi Tengah<br /><br />
            </td>
        </tr>
    </tbody>
</table>

<table width="100%">
    <tbody>
        <tr>
            <th width="33%"></th>
            <th width="33%" align="center">
                <u>KARTU BEROBAT PEGAWAI</u> <br />
                <small> <?php echo e($number); ?> </small>
            </th>
            <th width="33%"></th>
        </tr>
    </tbody>
</table>


<table width="100%" border="0">
    <tr>
        <td width="70%">

            <table border="0">
                <tbody>
                    <tr>
                        <td width="50%" style="font-weight:bold">NAMA PASIEN/PEGAWAI</td>
                        <td width="5%">:</td>
                        <td width="40%"><?php echo e($employee->name); ?></td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">GOLONGAN</td>
                        <td>:</td>
                        <td><?php echo e($employee->class); ?></td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">UNIT KERJA</td>
                        <td>:</td>
                        <td><?php echo e($employee->work_unit); ?></td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">ALAMAT</td>
                        <td>:</td>
                        <td><?php echo e($employee->address); ?></td>
                    </tr>
                </tbody>
            </table>

        </td>
        <td width="40%">

            <table border="0">
                <tbody>
                    <tr>
                        <td width="30%" style="font-weight:bold">UMUR</td>
                        <td width="5%">:</td>
                        <td width="50%"><?php echo e(Carbon\Carbon::parse($employee->date_of_birth)->age); ?> Thn</td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">JENIS KELAMIN</td>
                        <td>:</td>
                        <td><?php echo e($employee->gender); ?></td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">GOL. DARAH</td>
                        <td>:</td>
                        <td><?php echo e($employee->blood_type); ?></td>
                    </tr>
                </tbody>
            </table>

        </td>
    </tr>
</table>



<br />
<table width="100%" style="padding: 1px;" border="1">
    <tr style="background-color:rgb(217, 214, 214)">
        <th> TANGGAL </th>
        <th> TINGGI BADAN </th>
        <th> BERAT BADAN </th>
        <th> SUHU TUBUH </th>
        <th> TEKANAN DARAH </th>
        <th> HASIL PEMERIKSAAN DASAR</th>
        <th> PEMERIKSAAN FISIK </th>
        <th> DIAGNOSA </th>
        <th> TERAPI </th>
        <th> TANGGAL PERIKSA SELANJUTNYA </th>
    </tr>


    <?php if($type === 'check'): ?>
        <tr>
            <td> <?php echo e($check->date); ?> </td>
            <td> <?php echo e($check->tinggi); ?> </td>
            <td> <?php echo e($check->berat); ?> </td>
            <td> <?php echo e($check->suhu); ?> </td>
            <td> <?php echo e($check->tekanan); ?> </td>
            <td> <?php echo e($check->hasil); ?> </td>
            <td> <?php echo e($check->description); ?> </td>
            <td> <?php echo e($check->diagnosis); ?> </td>
            <td> <?php echo e($check->therapy); ?> </td>
            <td> <?php echo e($check->nextdate); ?></td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $check; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($detail->date); ?> </td>
                <td> <?php echo e($detail->tinggi); ?> </td>
                <td> <?php echo e($detail->berat); ?> </td>
                <td> <?php echo e($detail->suhu); ?> </td>
                <td> <?php echo e($detail->tekanan); ?> </td>
                <td> <?php echo e($detail->hasil); ?> </td>
                <td> <?php echo e($detail->description); ?> </td>
                <td> <?php echo e($detail->diagnosis); ?></td>
                <td> <?php echo e($detail->therapy); ?></td>
                <td> <?php echo e($detail->nextdate); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>
<?php /**PATH C:\xampp\htdocs\e-klinik\resources\views/pdf/check.blade.php ENDPATH**/ ?>