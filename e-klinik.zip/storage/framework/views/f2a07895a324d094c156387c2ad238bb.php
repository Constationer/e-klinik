  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span> <?php echo e($setting->value); ?> </span></strong>. All Rights Reserved
    </div>
  </footer><!-- End Footer --><?php /**PATH C:\xampp\htdocs\e-klinik\resources\views/partials/footer.blade.php ENDPATH**/ ?>