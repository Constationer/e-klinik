<?php $__env->startSection('content'); ?>

    <section class="section">

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong></strong> Terjadi Error : <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <div class="row">

            <!-- easyui datagrid table -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table id="dg" class="easyui-datagrid mt-2" style="width:99%;height:500px" singleSelect="true">
                            <thead frozen="true">
                                <tr>
                                    <th data-options='field:"code", sortable:true' width="15%">Nomor</th>
                                    <th data-options='field:"employees.name", sortable:true' width="15%">Nama Pegawai
                                    </th>
                                    <th data-options='field:"doctors.name", sortable:true' width="10%">Nama Dokter</th>
                                    <th data-options='field:"check_type", sortable:true' width="10%">Jenis Periksa</th>
                                    <th data-options='field:"date", sortable:true' width="10%">Tgl Periksa</th>
                                </tr>
                            </thead>
                            <thead>
                                <tr>
                                    <th data-options='field:"tinggi", sortable:true' width="10%">Tinggi Badan</th>
                                    <th data-options='field:"berat", sortable:true' width="10%">Berat Badan</th>
                                    <th data-options='field:"suhu", sortable:true' width="10%">Suhu Tubuh</th>
                                    <th data-options='field:"tekanan", sortable:true' width="10%">Tekanan Darah</th>
                                    <th data-options='field:"hasil", sortable:true' width="20%">Hasil Pemeriksaan Dasar
                                    </th>
                                    <th data-options='field:"description", sortable:true' width="20%">Pemeriksaan Fisik
                                    </th>
                                    <th data-options='field:"diagnosis", sortable:true' width="20%">Diagnosis</th>
                                    <th data-options='field:"therapy", sortable:true' width="20%">Terapi</th>
                                    <th data-options='field:"nextdate", sortable:true' width="20%">Tanggal Periksa
                                        Selanjutnya</th>
                                    <th data-options='field:"option"' width="20%">Opsi</th>
                                </tr>
                            </thead>
                        </table>
                        <div id="toolbar">
                            <?php if(in_array(1, $user_roles)): ?>
                                <a class="btn btn-info btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_add">Tambah
                                    Data Periksa</a>
                                <a class="btn btn-outline-info btn-sm m-1" data-bs-toggle="modal"
                                    data-bs-target="#modal_rm">Rekam Medis</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        
        <form method="POST" action="<?php echo e(route('periksa_submit')); ?>" autocomplete="off" id="form_add">
            <div class="modal fade" id="modal_add" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Tambah Data Pemeriksaan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="mb-1 div-error" style="display: none">
                                <div class="alert alert-danger d-flex align-items-center" role="alert">
                                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img"
                                        aria-label="Danger:">
                                        <use xlink:href="#exclamation-triangle-fill" />
                                    </svg>
                                    <div class="message-error"></div>
                                </div>
                            </div>

                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <h5 class="modal-title text-bold"><b>DATA PEMERIKSAAN</b></h5>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Nama Pegawai*</label>
                                        <select class="form-control" name="employee_id" id="employee_id" required>
                                            <option value="">Pilih Pegawai</option>
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Nama Dokter*</label>
                                        <select class="form-control" name="doctor_id" id="doctor_id" required>
                                            <option value="">Pilih Dokter</option>
                                            <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Jenis Periksa*</label>
                                        <select class="form-control" name="check_type" id="check_type" required>
                                            <option value="">Pilih Jenis Periksa</option>
                                            <option value="Periksa">Periksa</option>
                                            <option value="Non Periksa">Non Periksa</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tanggal Periksa*</label>
                                        <input id="date" class="form-control" type="date" name="date"
                                            required>
                                    </div>
                                </div>

                                <h5 class="modal-title text-bold"><b>PEMERIKSAAN DASAR</b></h5>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tinggi Badan*</label>
                                        <input id="tinggi" class="form-control" type="input" name="tinggi"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Berat Badan*</label>
                                        <input id="berat" class="form-control" type="input" name="berat"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Suhu Badan*</label>
                                        <input id="suhu" class="form-control" type="input" name="suhu"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tekanan Darah*</label>
                                        <input id="tekanan" class="form-control" type="input" name="tekanan"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Hasil Pemeriksaan Dasar*</label>
                                        <input id="hasil" class="form-control" type="input" name="hasil"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Pemeriksaan Fisik</label>
                                        <textarea id="description" class="form-control" name="description"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Diagnosis</label>
                                        <textarea id="diagnosis" class="form-control" name="diagnosis"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Terapi</label>
                                        <textarea id="therapy" class="form-control" name="therapy"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Tanggal Periksa Selanjutnya*</label>
                                        <input id="nextdate" class="form-control" type="date" name="nextdate"
                                            required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-info" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-info" id="btn_save">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        
        <form method="POST" action="<?php echo e(route('periksa_update')); ?>" autocomplete="off" id="form_edit">
            <div class="modal fade" id="modal_edit" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Data Pemeriksaan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="mb-1 div-error" style="display: none">
                                <div class="alert alert-danger d-flex align-items-center" role="alert">
                                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img"
                                        aria-label="Danger:">
                                        <use xlink:href="#exclamation-triangle-fill" />
                                    </svg>
                                    <div class="message-error"></div>
                                </div>
                            </div>

                            <input type="hidden" name="id" id="id">

                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <h5 class="modal-title text-bold"><b>DATA PEMERIKSAAN</b></h5>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Nama Pegawai*</label>
                                        <select class="form-control" name="employee_id" id="employee_id" required>
                                            <option value="">Pilih Pegawai</option>
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Nama Dokter*</label>
                                        <select class="form-control" name="doctor_id" id="doctor_id" required>
                                            <option value="">Pilih Dokter</option>
                                            <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Jenis Periksa*</label>
                                        <select class="form-control" name="check_type" id="check_type" required>
                                            <option value="">Pilih Jenis Periksa</option>
                                            <option value="Periksa">Periksa</option>
                                            <option value="Non Periksa">Non Periksa</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tanggal Periksa*</label>
                                        <input id="date" class="form-control" type="date" name="date"
                                            required>
                                    </div>
                                </div>

                                <h5 class="modal-title text-bold"><b>PEMERIKSAAN DASAR</b></h5>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tinggi Badan*</label>
                                        <input id="tinggi" class="form-control" type="input" name="tinggi"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Berat Badan*</label>
                                        <input id="berat" class="form-control" type="input" name="berat"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Suhu Badan*</label>
                                        <input id="suhu" class="form-control" type="input" name="suhu"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="">Tekanan Darah*</label>
                                        <input id="tekanan" class="form-control" type="input" name="tekanan"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Hasil Pemeriksaan Dasar*</label>
                                        <input id="hasil" class="form-control" type="input" name="hasil"
                                            required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Pemeriksaan Fisik</label>
                                        <textarea id="description" class="form-control" name="description"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Diagnosis</label>
                                        <textarea id="diagnosis" class="form-control" name="diagnosis"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Terapi</label>
                                        <textarea id="therapy" class="form-control" name="therapy"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label for="">Tanggal Periksa Selanjutnya*</label>
                                        <input id="nextdate" class="form-control" type="date" name="nextdate"
                                            required>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-info" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-info" id="btn_save">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        
        <div class="modal" tabindex="-1" id="modal_rm">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Rekam Medis Pegawai</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="">Nama Pegawai*</label>
                            <select class="form-control" id="pdf_employee_id" required>
                                <option value="">Pilih</option>
                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->akses); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-info" data-bs-dismiss="modal">Tutup</button>
                        <button type="button" class="btn btn-info" onclick="pdf_rm()">Lihat PDF</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- easyui js datagrid -->
        <script type="text/javascript">
            // js window onload
            $(function() {
                get_datagrid();
            });

            function get_datagrid() {

                $('#dg').datagrid({
                    url: "<?php echo e(route('periksa_data')); ?>",
                    method: 'get',
                    rownumbers: true,
                    singleSelect: true,
                    pagination: true,
                    fitColumns: true,
                    toolbar: '#toolbar',
                    pageSize: 10,
                    remoteFilter: true,
                    defaultFilterType: 'label'
                });

                // datagrid filter 
                $('#dg').datagrid('enableFilter', [{
                        field: 'code',
                        type: 'textbox',
                        'placeholder': 'Kode'
                    },
                    {
                        field: 'employees.name',
                        type: 'textbox'
                    },
                    {
                        field: 'doctors.name',
                        type: 'textbox'
                    },
                    {
                        field: 'check_type',
                        type: 'textbox'
                    },
                    {
                        field: 'date',
                        type: 'textbox'
                    },
                    {
                        field: 'tinggi',
                        type: 'textbox'
                    },
                    {
                        field: 'berat',
                        type: 'textbox'
                    },
                    {
                        field: 'suhu',
                        type: 'textbox'
                    },
                    {
                        field: 'tekanan',
                        type: 'textbox'
                    },
                    {
                        field: 'hasil',
                        type: 'textbox'
                    },
                    {
                        field: 'description',
                        type: 'textbox'
                    },
                    {
                        field: 'diagnosis',
                        type: 'textbox'
                    },
                    {
                        field: 'therapy',
                        type: 'textbox'
                    },
                    {
                        field: 'nextdate',
                        type: 'textbox'
                    }
                ]);

            }

            // js submit form add
            $('#form_add').submit(function(e) {
                e.preventDefault();
                $.ajax({
                    url: "<?php echo e(route('periksa_submit')); ?>",
                    method: "POST",
                    data: $('#form_add').serialize(),
                    dataType: "JSON",
                    success: function(data) {

                        if (data.status == false) {

                            var message_error = '';
                            $.each(data.message, function(key, value) {
                                message_error += value + '<br>';
                            });

                            $('#modal_add').find('.div-error').show()
                            $('#modal_add').find('.message-error').html('')
                            $('#modal_add').find('.message-error').html(message_error);

                        } else {

                            alert(data.message);

                            $('#modal_add').modal('hide');
                            $('#dg').datagrid('reload');
                            $('#form_add').trigger('reset');
                        }
                    }
                });
            });

            // delete data
            function remove(id) {
                $.messager.confirm('Confirm', 'Anda yakin hapus data ini?', function(r) {
                    if (r) {
                        $.ajax({
                            url: "master-obat-delete/" + id,
                            method: 'get',
                            dataType: 'json',
                            data: {},
                            success: function(response) {
                                alert(response.message);
                                $('#dg').datagrid('reload');
                            }
                        });
                    }
                });
            }

            // edit data
            function edit(id) {
                $.ajax({
                    url: "periksa-edit/" + id,
                    method: 'post',
                    dataType: 'json',
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {

                        var modal = $('#modal_edit');

                        modal.find('.div-error').hide();

                        modal.modal('show');

                        modal.find('#id').val(response.id);
                        modal.find('#employee_id').val(response.employee_id);
                        modal.find('#doctor_id').val(response.doctor_id);
                        modal.find('#check_type').val(response.check_type);
                        modal.find('#date').val(response.date);
                        modal.find('#tinggi').val(response.tinggi);
                        modal.find('#berat').val(response.berat);
                        modal.find('#suhu').val(response.suhu);
                        modal.find('#tekanan').val(response.tekanan);
                        modal.find('#hasil').val(response.hasil);
                        modal.find('#description').val(response.description);
                        modal.find('#diagnosis').val(response.diagnosis);
                        modal.find('#therapy').val(response.therapy);
                        modal.find('#nextdate').val(response.nextdate);
                    }
                });
            }

            // js submit form edit
            $('#form_edit').submit(function(e) {
                e.preventDefault();
                $.ajax({
                    url: "<?php echo e(route('periksa_update')); ?>",
                    method: "POST",
                    data: $('#form_edit').serialize(),
                    dataType: "JSON",
                    success: function(data) {

                        if (data.status == false) {

                            var message_error = '';
                            $.each(data.message, function(key, value) {
                                message_error += value + '<br>';
                            });

                            $('#modal_edit').find('.div-error').show()
                            $('#modal_edit').find('.message-error').html('')
                            $('#modal_edit').find('.message-error').html(message_error);

                        } else {

                            alert(data.message);

                            $('#modal_edit').modal('hide');
                            $('#dg').datagrid('reload');
                            $('#form_edit').trigger("reset");
                        }
                    }
                });
            });

            function pdf_rm() {

                var employee_id = $('#pdf_employee_id').val();

                if (employee_id == '') {
                    alert('Pilih nama pegawai');
                    return false;
                } else {
                    window.open("/pdf-check/rm/" + employee_id);
                }

            }
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-klinik\resources\views/periksa.blade.php ENDPATH**/ ?>