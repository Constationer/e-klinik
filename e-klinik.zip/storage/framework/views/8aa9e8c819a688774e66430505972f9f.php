<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title> <?php echo e($title); ?></title>
</head>

<table border="0" width="100%">
    <tbody>
        <tr>
            <td>
                <img src="<?php echo e(public_path() . '/assets/img/logo.png'); ?>" width="100px" height="100px">
            </td>
            <td align="center" style="font-weight: bold">
                Klinik Umum<br/>
                Badan Pemeriksa Keuangan Republik Indonesia<br/>
                Perwakilan Provinsi Sulawesi Tengah<br/><br/>
            </td>
            <td align="right"> Tahun <?php echo e($year); ?> </td>
        </tr>
    </tbody>
</table>

<table width="100%">
    <tbody>
        <tr>
            <th width="25%"></th>
            <th width="50%" align="center"> 
                <u>KARTU PERSEDIAAN OBAT</u> <br/>
                <small> <?php echo e($medicine->name); ?> / <?php echo e($medicine->code); ?> </small>
            </th>
            <th width="25%"></th>
        </tr>
    </tbody>
</table>


<table width="100%" border="0">
    <tr>
        <td width="50%">

            <table border="0">
                <tbody>
                    <tr>
                        <td style="font-weight:bold">Kode Obat</td>
                        <td>:</td>
                        <td><?php echo e($medicine->code); ?></td>
                    </tr>
                    <tr>
                        <td style="font-weight:bold">Kelompok Obat</td>
                        <td>:</td>
                        <td> <?php echo e($medicine->category); ?> </td>
                    </tr>
                </tbody>
            </table>

        </td>
        <td width="50%"> 

            <table border="0">
                <tbody>
                    <tr>
                        <td width="50%" style="font-weight:bold">Nama Obat</td>
                        <td width="5%">:</td>
                        <td width="40%"><?php echo e($medicine->name); ?></td>
                    </tr>
                    
                    <tr>
                        <td style="font-weight:bold">Satuan</td>
                        <td>:</td>
                        <td><?php echo e($medicine->unit); ?></td>
                    </tr>
                </tbody>
            </table>

        </td>
    </tr>
</table>


<br/>
<table width="100%" style="padding: 2px;" border="1">
    <tr style="background-color:rgb(217, 214, 214)">
        <th> No </th>
        <th> BAST/Pemeriksaan </th>
        <th> Tgl Masuk / Keluar </th>
        <th> Keterangan </th>
        <th> Masuk </th>
        <th> Keluar </th>
        <th> Saldo </th>
    </tr>
    
    <?php
        // $saldo_awal = $last_stock;
        $saldo = $last_stock;
    ?>

    <tr>
        <td align="center"> 1 </td>
        <td> </td>
        <td> </td>
        <td> saldo tahun sebelumnya </td>
        <td> </td>
        <td> </td>
        <td align="right"> <?php echo e($saldo); ?> </td>
    </tr>
    
    <?php $__currentLoopData = $mutation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php
            $saldo = $saldo + $medicine_detail->data_in - $medicine_detail->data_out;
        ?>

        <tr>
            <td align="center"> <?php echo e($loop->iteration+1); ?> </td>
            <td> <?php echo e($medicine_detail->data_number); ?> </td>
            <td> <?php echo e($medicine_detail->data_date); ?> </td>
            <td> <?php echo e($medicine_detail->data_desc); ?> </td>
            <td align="right"> <?php echo e($medicine_detail->data_in); ?> </td>
            <td align="right"> <?php echo e($medicine_detail->data_out); ?> </td>
            <td align="right"> <?php echo e($saldo); ?> </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
</table><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/pdf/medicine-per-item.blade.php ENDPATH**/ ?>