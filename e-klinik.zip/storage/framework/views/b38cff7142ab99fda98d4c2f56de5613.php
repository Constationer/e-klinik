<?php $__env->startSection('content'); ?>

<section>
    <form action="<?php echo e(route('pengaturan_update')); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="card">

            
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($errors); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            

            <div class="card-body">
                <div class="row">                    
                    <div class="col-lg-12">
                        <div class="mb-2 mt-2">
                            <label for="" class="form-label">Nama Website*</label>
                            <input type="text" class="form-control" id="web_name" name="web_name" value="<?php echo e($web_name); ?>" required>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="mb-2">
                            <label for="" class="form-label">Deskripsi Website*</label>
                            <textarea class="form-control" id="web_desc" name="web_desc" rows="3" required><?php echo e($web_desc); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="mb-2 mt-4">
                            <?php if(in_array(1, $user_roles)): ?>
                                <button type="submit" class="btn btn-info">Simpan</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/pengaturan.blade.php ENDPATH**/ ?>