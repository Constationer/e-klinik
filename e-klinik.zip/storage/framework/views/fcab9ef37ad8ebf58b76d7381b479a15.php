;

<?php
    echo '<pre>';
    print_r($_SESSION);
    echo '</pre>';
?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-body">
            
            <table class="table table-light table-bordered mt-2">
                <thead>
                    <tr class="font-weight-bold"> 
                        <th> No </th>
                        <th> Waktu </th>
                        <th> Aktifitas </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($key+1); ?></td>
                            <td> <?php echo e($act->updated_at); ?> </td>
                            <td> [<?php echo e($act->source); ?>] <?php echo e($act->description); ?> oleh <?php echo e($act->user_name); ?> </td>
                        </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fahmi/Sites/e-klinik/resources/views/logs.blade.php ENDPATH**/ ?>