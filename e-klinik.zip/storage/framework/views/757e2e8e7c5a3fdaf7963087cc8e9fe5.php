<?php $__env->startSection('content'); ?>
halaman setting
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fahmi/Sites/e-klinik/resources/views/setting.blade.php ENDPATH**/ ?>