<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

		<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

            <?php if(App\Models\Menu::menuSub($menu->id)->count() == 0): ?>
				
				<li class="nav-item">
					<a class="nav-link " href="/<?php echo e($menu->link); ?>">
						<i class="<?php echo e($menu->icon); ?>"></i>
						<span> <?php echo e($menu->name); ?> </span>
					</a>
				</li>
			<?php else: ?>

			<li class="nav-item">
				<a
					class="nav-link collapsed"
					data-bs-target="#<?php echo e($menu->name); ?>-nav"
					data-bs-toggle="collapse"
					href="#">
					<i class="<?php echo e($menu->icon); ?>"></i>
					<span> <?php echo e($menu->name); ?> </span>
					<i class="bi bi-chevron-down ms-auto"></i>
				</a>

				<ul id="<?php echo e($menu->name); ?>-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
					<?php $__currentLoopData = App\Models\Menu::menuSub($menu->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<a href="/<?php echo e($menu_sub->link); ?>">
							<i class="bi bi-circle"></i>
							<span> <?php echo e($menu_sub->name); ?> </span>
						</a>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>

			</li>

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		

        

</aside>
<!-- End Sidebar--><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>