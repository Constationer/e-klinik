<h1><?php echo e($title); ?></h1>
<h3>Periode : <?php echo e($start_date); ?> s/d <?php echo e($end_date); ?></h3>
<h3>Klinik Perwakilan Provinsi Sulawesi Tengah</h3>

<br/><br/>
<table border="1" width="100%">
    <thead>
        <tr style="background-color: beige">
            <th>No</th>
            <th>Nomor</th>
            <th>Nama Pegawai</th>
            <th> Nama Dokter </th>
            <th> Jenis Periksa </th>
            <th> Tgl Periksa </th>
        </tr>
    </thead>
        <?php
            $i = 1;
        ?> 

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($check->code); ?></td>
                <td><?php echo e($check->employee_name); ?></td>
                <td><?php echo e($check->doctor_name); ?></td>
                <td><?php echo e($check->check_type); ?></td>
                <td><?php echo e($check->date); ?></td>
            </tr>

            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
    <tbody>

    </tbody>
</table><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/exports/checks.blade.php ENDPATH**/ ?>