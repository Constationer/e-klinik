<h1>Laporan Persediaan Obat-Obatan</h1>
<h3>Periode : <?php echo e($start_date); ?> s/d <?php echo e($end_date); ?></h3>
<h3>Klinik Perwakilan Provinsi Sulawesi Tengah</h3>

<br/><br/>
<table border="1" width="100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Obat</th>
            <th>Satuan</th>
            <th> Jumlah Awal </th>
            <th> Masuk </th>
            <th> Keluar </th>
            <th> Jumlah Akhir </th>
            <th> Expired Date </th>
            <th> Umur Obat (dalam bulan) </th>
            <th> Status </th>
        </tr>
    </thead>
        <?php
            $i = 1;
        ?> 

        <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php
            $jumlah_akhir = $value->stock_awal + $value->stock_in - $value->stock_out;
            $month_diff = \App\Helper\General::get_date_diff($value->expired_date, date('Y-m-d'));        

            $status = $value->status_stock;
        ?>

            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->unit); ?></td>
                <td><?php echo e($value->stock_awal); ?></td>
                <td><?php echo e($value->stock_in); ?></td>
                <td><?php echo e($value->stock_out); ?></td>
                <td><?php echo e($jumlah_akhir); ?></td>
                <td><?php echo e($value->expired_date); ?></td>
                <td><?php echo e($month_diff['months']); ?></td>
                <td><?php echo e($status); ?></td>
            </tr>

            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
    <tbody>

    </tbody>
</table><?php /**PATH /home1/ulemmoco/public_html/#other_domain/kodepoin.com/demo/e-klinik/resources/views/exports/medicines.blade.php ENDPATH**/ ?>